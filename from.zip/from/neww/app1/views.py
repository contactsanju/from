from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import details
from .forms import data


def neww1(request):
    return render(request, 'index.html')


def reg(request):
 if request.method == 'POST':
    a = data(request.POST)
    if a.is_valid():
        oname = a.cleaned_data['oname']
        outype = a.cleaned_data['outype']
        gnum = a.cleaned_data['gnum']
        fnum = a.cleaned_data['fnum']
        opnum = a.cleaned_data['opnum']
        oadd = a.cleaned_data['oadd']
        city = a.cleaned_data['city']
        pcode = a.cleaned_data['pcode']
        onum = a.cleaned_data['onum']
        emaill = a.cleaned_data['emaill']
        passs = a.cleaned_data['passs']
        cpass = a.cleaned_data['cpass']
        comm = a.cleaned_data['comm']
        ename = a.cleaned_data['ename']
        eid = a.cleaned_data['eid']
        bname = a.cleaned_data['bname']
        hname = a.cleaned_data['hname']
        acntnum = a.cleaned_data['acntnum']
        ifscnum = a.cleaned_data['ifscnum']
        latti = a.cleaned_data['latti']
        longi = a.cleaned_data['longi']

        b = details(oname=oname, outype=outype, gnum=gnum, fnum=fnum, opnum=opnum, oadd=oadd, city=city, pcode=pcode, onum=onum, emaill=emaill, passs=passs, cpass=cpass, comm=comm, ename=ename, eid=eid, bname=bname, hname=hname, acntnum=acntnum, ifscnum=ifscnum, latti=latti, longi=longi)
        b.save()
        return HttpResponse('registration complete')
    else:
        oname = a.cleaned_data['oname']
        outype = a.cleaned_data['outype']
        gnum = a.cleaned_data['gnum']
        fnum = a.cleaned_data['fnum']
        opnum = a.cleaned_data['opnum']
        oadd = a.cleaned_data['oadd']
        city = a.cleaned_data['city']
        pcode = a.cleaned_data['pcode']
        onum = a.cleaned_data['onum']
        emaill = a.cleaned_data['emaill']
        passs = a.cleaned_data['passs']
        cpass = a.cleaned_data['cpass']
        comm = a.cleaned_data['comm']
        ename = a.cleaned_data['ename']
        eid = a.cleaned_data['eid']
        bname = a.cleaned_data['bname']
        hname = a.cleaned_data['hname']
        acntnum = a.cleaned_data['acntnum']
        ifscnum = a.cleaned_data['ifscnum']
        latti = a.cleaned_data['latti']
        longi = a.cleaned_data['longi']

        b = details(oname=oname, outype=outype, gnum=gnum, fnum=fnum, opnum=opnum, oadd=oadd, city=city, pcode=pcode, onum=onum, emaill=emaill, passs=passs, cpass=cpass, comm=comm, ename=ename, eid=eid, bname=bname, hname=hname, acntnum=acntnum, ifscnum=ifscnum, latti=latti, longi=longi)
        b.save()
        return HttpResponse('registration complete')
 else:
     return render(request,'index.html')
