from django.db import models


class details(models.Model):
    oname = models.CharField(max_length=20)
    outype = models.CharField(max_length=20)
    gnum = models.CharField(max_length=20)
    fnum = models.CharField(max_length=20)
    opnum = models.CharField(max_length=20)
    oadd = models.CharField(max_length=40)
    city = models.CharField(max_length=15)
    pcode = models.CharField(max_length=10)
    onum = models.CharField(max_length=15)
    emaill = models.CharField(max_length=20)
    passs = models.CharField(max_length=30)
    cpass = models.CharField(max_length=30)
    comm = models.CharField(max_length=10)
    ename = models.CharField(max_length=20)
    eid = models.CharField(max_length=10)
    bname = models.CharField(max_length=20)
    hname = models.CharField(max_length=20)
    acntnum = models.CharField(max_length=20)
    ifscnum = models.CharField(max_length=20)
    latti = models.CharField(max_length=20)
    longi = models.CharField(max_length=20)






