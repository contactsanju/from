from django import forms

class data(forms.Form):
    oname = forms.CharField(max_length=20)
    outype = forms.CharField(max_length=20)
    gnum = forms.CharField(max_length=20)
    fnum = forms.CharField(max_length=20)
    opnum = forms.CharField(max_length=20)
    oadd = forms.CharField(max_length=40)
    city = forms.CharField(max_length=15)
    pcode = forms.CharField(max_length=10)
    onum = forms.CharField(max_length=15)
    emaill = forms.CharField(max_length=20)
    passs = forms.CharField(max_length=30)
    cpass = forms.CharField(max_length=30)
    comm = forms.CharField(max_length=10)
    ename = forms.CharField(max_length=20)
    eid = forms.CharField(max_length=10)
    bname = forms.CharField(max_length=20)
    hname = forms.CharField(max_length=20)
    acntnum = forms.CharField(max_length=20)
    ifscnum = forms.CharField(max_length=20)
    latti = forms.CharField(max_length=20)
    longi = forms.CharField(max_length=20)



